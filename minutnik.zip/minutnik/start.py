import pygame
from pygame import mixer
pygame.mixer.init()
sekunda= pygame.mixer.Sound('star wars blaster sound effect.mp3')
koniec= pygame.mixer.Sound('explosion SOUND effect.mp3')
while True:
    czas=int(input("wpisz ilości czasu w sekundach:"))
    while czas>0:
        print(czas)
        czas-=1
        pygame.mixer.Sound.play(sekunda)
        pygame.time.wait(1000)
    print(" ")
    print('koniec')
    print(" ")
    print(" ")
    pygame.mixer.Sound.play(koniec)












    
